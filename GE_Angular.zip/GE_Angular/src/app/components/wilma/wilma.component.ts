import { Component } from '@angular/core';

@Component({
  selector: 'wilma',
  templateUrl: './wilma.component.html',
  styleUrls: ['./wilma.component.css']
})
export class WilmaComponent {
  //title = 'Prueba';

}