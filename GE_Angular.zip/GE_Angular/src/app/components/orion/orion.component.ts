import { Component } from '@angular/core';

@Component({
  selector: 'orion',
  templateUrl: './orion.component.html',
  styleUrls: ['./orion.component.css']
})
export class OrionComponent {
  //title = 'Prueba';

}