import { Component } from '@angular/core';

@Component({
  selector: 'ejemplo',
  templateUrl: './ejemplo.component.html',
  styleUrls: ['./ejemplo.component.css']
})
export class EjemploComponent {
  //title = 'Prueba';

}