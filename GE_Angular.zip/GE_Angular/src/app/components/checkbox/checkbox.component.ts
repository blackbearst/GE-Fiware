import { Component } from '@angular/core';

@Component({
  selector: 'check',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent {
  //title = 'Prueba';

}