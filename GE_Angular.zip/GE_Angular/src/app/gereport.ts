export class GeReport{
    _id?: string;
    GE_name: string;
    Version: string;
    Test: string;
    Execution_time: string;
    Data: string;
    Time: string;
    containers: string;
    n?: number;
}