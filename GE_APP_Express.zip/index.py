import os

#print("holamundo")
#print("hello :p")
os.system('cd GE-Fiware && python index.py')
